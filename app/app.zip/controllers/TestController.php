<?php

use Aws\S3\S3Client;
use app\LangHelper;
use Intervention\Image\Facades;


class TestController extends BaseController{
	protected $whitelist = array('test', 'seoUrlGenerate', 'videoThumbGenerate');

	public function test(){
        $video = Video::find(80);
        Util::trace($video->seo_url);
    }

    public function videoThumbGenerate(){
        set_time_limit(0);
        $video = Video::find(1382);

        $vts = VideoThumbnailSmall::where('video_id', $video->id)->first();
        if(empty($vts)){

            $size = [220, 130];
            $size_prefix = trim(implode('x',$size), 'x').'';
            $img_name = 'juni.jpg';
            $key = $video->id.'/thumbnails/'.$size_prefix.'/'.$img_name;
            $destination = 'uploads/videothumbs/'.$img_name;


            //generate thumbnail
            $img = Image::make( $video->getThumbnail() );// open an image file
            $img->resize(220, 130); // now you are able to resize the instance
            $img->save( $destination );// finally we save the image as a new file


            //upload to amazon
            $s3 = App::make('aws')->get('s3');
            $s3->putObject(array(
                'Bucket'     => 'telfazi',
                'Key'        => $key,
                'SourceFile' => $destination
            ));

            //save to database
            $vts = new VideoThumbnailSmall();
            $vts->video_id = $video->id;
            $vts->key = $key;
            $vts->save();

            //remove thumbnail from local
            unlink( $destination );
        }else{
            echo 'video '.$video->id.' already generated';
        }
    }

    //generate seo url from videos with english language.
    public function seoUrlGenerate(){
        $videos = Video::byLanguage(2)->get();
        foreach($videos as $v){
            if( is_null($v->seo_url)){
                $v->seo_url = Util::seoUrl( $v->getTitle() );
                $v->save();
            }
        }
    }
}
