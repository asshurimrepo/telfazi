@extends('layouts.alphaprofile')

@section('content')

<div id="videoliked">
	@include('video.lists.videosliked')	
</div>

@stop

