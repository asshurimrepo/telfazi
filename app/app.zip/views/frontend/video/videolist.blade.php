
<!-- video list start --> 
<div class="video-group scrollbox"> 
  <div class="video-box">
    <div class="video-desc">
      <h2><a class="video-link" href="?videos=video1.mp4">هدف كاكا الصاروخي على لاتسيو</a></h2>
       <span>asdasdasdasd asdas asda sdas</span><br>
      by <span class="video-author"><a href="#">asdadsa</a></span><br>
      <span class="video-time"> 3:14 </span>
    </div>
    <div class="video-thumb"><img src="{{ asset('assets/img/vid1.jpg') }}" alt="image" /></div>
    <div class="clearfix"></div>
  </div>

  <div class="video-box">
    <div class="video-desc">
      <h2><a class="video-link" href="?videos=video2.mp4">بالفيديو- هدف التعادل للميلان عن طريق كاكا</a></h2>
       <span>asdasdasdasd asdas asda sdas</span><br>
      by <span class="video-author"><a href="#">asdadsa</a></span><br>
      <span class="video-time"> 3:14 </span>
    </div>
    <div class="video-thumb"><img src="{{ asset('{{ asset('assets/img/vid1.jpg') }}') }}" alt="image" /></div>
    <div class="clearfix"></div>
  </div>

  <div class="video-box">
    <div class="video-desc">
      <h2><a class="video-link" href="?videos=video3.mp4">لة الجزاء العالمية التي فيتش في مرمى باير ليفركوزن</a></h2>
       <span>asdasdasdasd asdas asda sdas</span><br>
      by <span class="video-author"><a href="#">asdadsa</a></span><br>
      <span class="video-time"> 3:14 </span>
    </div>
    <div class="video-thumb"><img src="{{ asset('assets/img/vid1.jpg') }}" alt="image" /></div>
    <div class="clearfix"></div>
  </div>

  <div class="video-box">
    <div class="video-desc">
      <h2><a class="video-link" href="?videos=video4.mp4">ال26 ضمن منافسات هوميلس لاعب بوروسيا دورتموند</a></h2>
       <span>asdasdasdasd asdas asda sdas</span><br>
      by <span class="video-author"><a href="#">asdadsa</a></span><br>
      <span class="video-time"> 3:14 </span>
    </div>
    <div class="video-thumb"><img src="{{ asset('assets/img/vid1.jpg') }}" alt="image" /></div>
    <div class="clearfix"></div>
  </div>

  <div class="video-box">
    <div class="video-desc">
      <h2><a class="video-link" href="?videos=video5.mp4">أهداف للبرازيلي روبرت فيرمينو لاعب هوفينهايم الألماني</a></h2>
       <span>asdasdasdasd asdas asda sdas</span><br>
      by <span class="video-author"><a href="#">asdadsa</a></span><br>
      <span class="video-time"> 3:14 </span>
    </div>
    <div class="video-thumb"><img src="{{ asset('assets/img/vid1.jpg') }}" alt="image" /></div>
    <div class="clearfix"></div>
  </div>

  <div class="video-box">
    <div class="video-desc">
      <h2><a class="video-link" href="?videos=video6.mp4">أهداف للبرازيلي روبرت فيرمينو لاعب هوفينهايم الألماني</a></h2>
       <span>asdasdasdasd asdas asda sdas</span><br>
      by <span class="video-author"><a href="#">asdadsa</a></span><br>
      <span class="video-time"> 3:14 </span>
    </div>
    <div class="video-thumb"><img src="{{ asset('assets/img/vid1.jpg') }}" alt="image" /></div>
    <div class="clearfix"></div>
  </div>

  <div class="video-box">
    <div class="video-desc">
      <h2><a class="video-link" href="?videos=video7.mp4">أهداف للبرازيلي روبرت فيرمينو لاعب هوفينهايم الألماني</a></h2>
       <span>asdasdasdasd asdas asda sdas</span><br>
      by <span class="video-author"><a href="#">asdadsa</a></span><br>
      <span class="video-time"> 3:14 </span>
    </div>
    <div class="video-thumb"><img src="{{ asset('assets/img/vid1.jpg') }}" alt="image" /></div>
    <div class="clearfix"></div>
  </div>

  <div class="video-box">
    <div class="video-desc">
      <h2><a class="video-link" href="?videos=video8.mp4">أهداف للبرازيلي روبرت فيرمينو لاعب هوفينهايم الألماني</a></h2>
       <span>asdasdasdasd asdas asda sdas</span><br>
      by <span class="video-author"><a href="#">asdadsa</a></span><br>
      <span class="video-time"> 3:14 </span>
    </div>
    <div class="video-thumb"><img src="{{ asset('assets/img/vid1.jpg') }}" alt="image" /></div>
    <div class="clearfix"></div>
  </div>
</div>
<!-- video list end --> 