<!-- Channel A type -->
        <div class="channel channelA">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <button class="btn btn-channel">Soccer Channel</button>

                <div class="line-separator"></div>
              </div>
            </div>
            <div class="row">
                <div class="col-sm-6 col-md-3">
              <div class="thumbnail"> <!-- start thumbnail -->
                <img data-src="" src="assets/img/thumb1.jpg" alt="...">
                <div class="caption">
                  <h4 class="text-center">ممانعة مغناطيسية ناطي ممانعة مغناطيسية</h4>
                  <span class="little"><p class="text-center">00:18</p></span>
                </div>
              </div>
            </div> <!-- end thumbnail -->  
            <div class="col-sm-6 col-md-3">
              <div class="thumbnail"> <!-- start thumbnail -->
                <img data-src="" src="assets/img/thumb1.jpg" alt="...">
                <div class="caption">
                  <h4 class="text-center">ممانعة مغناطيسية ناطي ممانعة مغناطيسية</h4>
                  <span class="little"><p class="text-center">00:18</p></span>
                </div>
              </div>
            </div> <!-- end thumbnail -->  
            <div class="col-sm-6 col-md-3">
              <div class="thumbnail"> <!-- start thumbnail -->
                <img data-src="" src="assets/img/thumb1.jpg" alt="...">
                <div class="caption">
                  <h4 class="text-center">ممانعة مغناطيسية ناطي ممانعة مغناطيسية</h4>
                  <span class="little"><p class="text-center">00:18</p></span>
                </div>
              </div>
            </div> <!-- end thumbnail -->  
            <div class="col-sm-6 col-md-3">
              <div class="thumbnail"> <!-- start thumbnail -->
                <img data-src="" src="assets/img/thumb1.jpg" alt="...">
                <div class="caption">
                  <h4 class="text-center">ممانعة مغناطيسية ناطي ممانعة مغناطيسية</h4>
                  <span class="little"><p class="text-center">00:18</p></span>
                </div>
              </div>
            </div> <!-- end thumbnail -->  
            <div class="col-sm-6 col-md-3">
              <div class="thumbnail"> <!-- start thumbnail -->
                <img data-src="" src="assets/img/thumb1.jpg" alt="...">
                <div class="caption">
                  <h4 class="text-center">ممانعة مغناطيسية ناطي ممانعة مغناطيسية</h4>
                  <span class="little"><p class="text-center">00:18</p></span>
                </div>
              </div>
            </div> <!-- end thumbnail -->  
            <div class="col-sm-6 col-md-3">
              <div class="thumbnail"> <!-- start thumbnail -->
                <img data-src="" src="assets/img/thumb1.jpg" alt="...">
                <div class="caption">
                  <h4 class="text-center">ممانعة مغناطيسية ناطي ممانعة مغناطيسية</h4>
                  <span class="little"><p class="text-center">00:18</p></span>
                </div>
              </div>
            </div> <!-- end thumbnail -->  
            <div class="col-sm-6 col-md-3">
              <div class="thumbnail"> <!-- start thumbnail -->
                <img data-src="" src="assets/img/thumb1.jpg" alt="...">
                <div class="caption">
                  <h4 class="text-center">ممانعة مغناطيسية ناطي ممانعة مغناطيسية</h4>
                  <span class="little"><p class="text-center">00:18</p></span>
                </div>
              </div>
            </div> <!-- end thumbnail -->  
            <div class="col-sm-6 col-md-3">
              <div class="thumbnail"> <!-- start thumbnail -->
                <img data-src="" src="assets/img/thumb1.jpg" alt="...">
                <div class="caption">
                  <h4 class="text-center">ممانعة مغناطيسية ناطي ممانعة مغناطيسية</h4>
                  <span class="little"><p class="text-center">00:18</p></span>
                </div>
              </div>
            </div> <!-- end thumbnail -->  
            </div>
          </div>
        </div>
        <!-- Channel A type -->

        <!-- Channel B type -->
        <div class="channel channelB">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <button class="btn btn-channel">Audios Channel</button>

                <div class="line-separator"></div>
              </div>
            </div>
            <div class="row">
                <div class="col-sm-6 col-md-3">
              <div class="thumbnail"> <!-- start thumbnail -->
                <img data-src="" src="assets/img/thumb1.jpg" alt="...">
                <div class="caption">
                  <h4 class="text-center">ممانعة مغناطيسية ناطي ممانعة مغناطيسية</h4>
                  <span class="little"><p class="text-center">00:18</p></span>
                </div>
              </div>
            </div> <!-- end thumbnail -->  
            <div class="col-sm-6 col-md-3">
              <div class="thumbnail"> <!-- start thumbnail -->
                <img data-src="" src="assets/img/thumb1.jpg" alt="...">
                <div class="caption">
                  <h4 class="text-center">ممانعة مغناطيسية ناطي ممانعة مغناطيسية</h4>
                  <span class="little"><p class="text-center">00:18</p></span>
                </div>
              </div>
            </div> <!-- end thumbnail -->  
            <div class="col-sm-6 col-md-3">
              <div class="thumbnail"> <!-- start thumbnail -->
                <img data-src="" src="assets/img/thumb1.jpg" alt="...">
                <div class="caption">
                  <h4 class="text-center">ممانعة مغناطيسية ناطي ممانعة مغناطيسية</h4>
                  <span class="little"><p class="text-center">00:18</p></span>
                </div>
              </div>
            </div> <!-- end thumbnail -->  
            <div class="col-sm-6 col-md-3">
              <div class="thumbnail"> <!-- start thumbnail -->
                <img data-src="" src="assets/img/thumb1.jpg" alt="...">
                <div class="caption">
                  <h4 class="text-center">ممانعة مغناطيسية ناطي ممانعة مغناطيسية</h4>
                  <span class="little"><p class="text-center">00:18</p></span>
                </div>
              </div>
            </div> <!-- end thumbnail -->  
            <div class="col-sm-6 col-md-3">
              <div class="thumbnail"> <!-- start thumbnail -->
                <img data-src="" src="assets/img/thumb1.jpg" alt="...">
                <div class="caption">
                  <h4 class="text-center">ممانعة مغناطيسية ناطي ممانعة مغناطيسية</h4>
                  <span class="little"><p class="text-center">00:18</p></span>
                </div>
              </div>
            </div> <!-- end thumbnail -->  
            <div class="col-sm-6 col-md-3">
              <div class="thumbnail"> <!-- start thumbnail -->
                <img data-src="" src="assets/img/thumb1.jpg" alt="...">
                <div class="caption">
                  <h4 class="text-center">ممانعة مغناطيسية ناطي ممانعة مغناطيسية</h4>
                  <span class="little"><p class="text-center">00:18</p></span>
                </div>
              </div>
            </div> <!-- end thumbnail -->  
            <div class="col-sm-6 col-md-3">
              <div class="thumbnail"> <!-- start thumbnail -->
                <img data-src="" src="assets/img/thumb1.jpg" alt="...">
                <div class="caption">
                  <h4 class="text-center">ممانعة مغناطيسية ناطي ممانعة مغناطيسية</h4>
                  <span class="little"><p class="text-center">00:18</p></span>
                </div>
              </div>
            </div> <!-- end thumbnail -->  
            <div class="col-sm-6 col-md-3">
              <div class="thumbnail"> <!-- start thumbnail -->
                <img data-src="" src="assets/img/thumb1.jpg" alt="...">
                <div class="caption">
                  <h4 class="text-center">ممانعة مغناطيسية ناطي ممانعة مغناطيسية</h4>
                  <span class="little"><p class="text-center">00:18</p></span>
                </div>
              </div>
            </div> <!-- end thumbnail -->  
            </div>
          </div>
        </div>
        <!-- Channel B type -->

        <!-- Channel A type -->
        <div class="channel channelA">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <button class="btn btn-channel">Tourism Channel</button>

                <div class="line-separator"></div>
              </div>
            </div>
            <div class="row">
                <div class="col-sm-6 col-md-3">
              <div class="thumbnail"> <!-- start thumbnail -->
                <img data-src="" src="assets/img/thumb1.jpg" alt="...">
                <div class="caption">
                  <h4 class="text-center">ممانعة مغناطيسية ناطي ممانعة مغناطيسية</h4>
                  <span class="little"><p class="text-center">00:18</p></span>
                </div>
              </div>
            </div> <!-- end thumbnail -->  
            <div class="col-sm-6 col-md-3">
              <div class="thumbnail"> <!-- start thumbnail -->
                <img data-src="" src="assets/img/thumb1.jpg" alt="...">
                <div class="caption">
                  <h4 class="text-center">ممانعة مغناطيسية ناطي ممانعة مغناطيسية</h4>
                  <span class="little"><p class="text-center">00:18</p></span>
                </div>
              </div>
            </div> <!-- end thumbnail -->  
            <div class="col-sm-6 col-md-3">
              <div class="thumbnail"> <!-- start thumbnail -->
                <img data-src="" src="assets/img/thumb1.jpg" alt="...">
                <div class="caption">
                  <h4 class="text-center">ممانعة مغناطيسية ناطي ممانعة مغناطيسية</h4>
                  <span class="little"><p class="text-center">00:18</p></span>
                </div>
              </div>
            </div> <!-- end thumbnail -->  
            <div class="col-sm-6 col-md-3">
              <div class="thumbnail"> <!-- start thumbnail -->
                <img data-src="" src="assets/img/thumb1.jpg" alt="...">
                <div class="caption">
                  <h4 class="text-center">ممانعة مغناطيسية ناطي ممانعة مغناطيسية</h4>
                  <span class="little"><p class="text-center">00:18</p></span>
                </div>
              </div>
            </div> <!-- end thumbnail -->  
            <div class="col-sm-6 col-md-3">
              <div class="thumbnail"> <!-- start thumbnail -->
                <img data-src="" src="assets/img/thumb1.jpg" alt="...">
                <div class="caption">
                  <h4 class="text-center">ممانعة مغناطيسية ناطي ممانعة مغناطيسية</h4>
                  <span class="little"><p class="text-center">00:18</p></span>
                </div>
              </div>
            </div> <!-- end thumbnail -->  
            <div class="col-sm-6 col-md-3">
              <div class="thumbnail"> <!-- start thumbnail -->
                <img data-src="" src="assets/img/thumb1.jpg" alt="...">
                <div class="caption">
                  <h4 class="text-center">ممانعة مغناطيسية ناطي ممانعة مغناطيسية</h4>
                  <span class="little"><p class="text-center">00:18</p></span>
                </div>
              </div>
            </div> <!-- end thumbnail -->  
            <div class="col-sm-6 col-md-3">
              <div class="thumbnail"> <!-- start thumbnail -->
                <img data-src="" src="assets/img/thumb1.jpg" alt="...">
                <div class="caption">
                  <h4 class="text-center">ممانعة مغناطيسية ناطي ممانعة مغناطيسية</h4>
                  <span class="little"><p class="text-center">00:18</p></span>
                </div>
              </div>
            </div> <!-- end thumbnail -->  
            <div class="col-sm-6 col-md-3">
              <div class="thumbnail"> <!-- start thumbnail -->
                <img data-src="" src="assets/img/thumb1.jpg" alt="...">
                <div class="caption">
                  <h4 class="text-center">ممانعة مغناطيسية ناطي ممانعة مغناطيسية</h4>
                  <span class="little"><p class="text-center">00:18</p></span>
                </div>
              </div>
            </div> <!-- end thumbnail -->  
            </div>
          </div>
        </div>
        <!-- Channel A type -->