
  <div class="container"> <!-- container start -->
    <div class="row ">
      <div class="col-md-7 no-space">
        <div class="video-header "><h2>This is my video title</h2></div>
        <div id="video-control">
          <div id="myElement">Loading the player...</div>
        </div>
      </div>


      <div class="col-md-5 no-space">
        <div class="video-header gradient-black "><h2>Other Videos</h2></div>
        
          @include('frontend.video.videolist');
      
      </div>
    <div class="clearfix"></div>
    </div>
  </div> <!-- container end -->
