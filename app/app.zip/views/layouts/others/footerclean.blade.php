

<div class="clearfix"></div>
<div id="footer">

 
    <div class="container">
      <div class="row">
        <div class="col-md-12">Copyright @ Telfasi 2014</div>
      </div>
    </div>
  
  <div class="clearfix"></div>
</div>