<div class="row">
  <div class="separator-space-sm"></div>
  <div class="col-md-12">
    <ul class="list-unstyled list-inline pull-right socialbtns">
      <li class="ti">{{ Lang::get('lang.follow_us')}}</li>
      <!-- <li><img src="{{ asset('assets/img/rss_icon.png') }}"> </li> -->
      <li><a href="{{ $twitter_url }}"><img src="{{ asset('assets/img/twitter.png') }}"></a></li>
      <li><a href="{{ $facebook_url }}"><img src="{{ asset('assets/img/facebok.png') }}"></a></li>
    </ul>
  </div>
</div>