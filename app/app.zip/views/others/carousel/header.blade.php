
<div id="carousel-example-generic" class="carousel slide feeder-carousel" data-ride="carousel">
  	<!-- Wrapper for slides -->
  	<div class="carousel-inner">


  		