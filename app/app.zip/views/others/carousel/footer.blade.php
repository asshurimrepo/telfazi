	</div>

	<!-- Controls -->
	<a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
	<span class="left-control"> <img src="{{ asset('assets/img/carleft_c.png') }}"> </span>
	</a>
	<a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
	<span class="right-control"> <img src="{{ asset('assets/img/carright_c.png') }}"> </span>
	</a>
</div>
