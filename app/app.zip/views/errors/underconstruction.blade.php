@extends('layouts.alphablank')


@section('content')
  
  <div class="notfound text-center" style="min-height: 300px; margin-top: 100px;"> 

    <h2><b>Coming Soon</b></h2>
    <p><b>We`re working hard to improve our website <br>and we are ready to launch soon.</b></p>

  </div>

@stop


<style type="text/css">
.notfound{ color:#333; font-weight: bolder; font-family: 'Verdana' }
.notfound h2{  font-size: 50px; }
.notfound p{ color:#666; font-size: 20px;}
.notfound .searchhub p{ margin-top:60px; color:#333; text-align: left;  font-size: 14px;}
</style>