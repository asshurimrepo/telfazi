<div style="text-align:left">
	<img src="{{ asset('assets/img/logodark.png') }}" width="100">
</div>
<div style="clear:both"></div>
