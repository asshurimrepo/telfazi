@include('emails/logo')


<p><b>Dear Asshurim Larita,</b></p>

<p>You recently initiated a password reset for your Telfazi ID. To complete the process, click the link below.</p>

<p><a href="">Reset Now</a> </p>

<p>This link will expire three hours after this email was sent.</p>

<p>
	If you didn’t make this request, it's likely that another user has entered your email address by mistake and your account is still secure. If you believe an unauthorized person has accessed your account, you can reset your password.
</p>
<br>
<p>Telfazi Support</p>

