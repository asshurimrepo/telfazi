<div class="bg-info info-head" style="">
		<i class="fa fa-facebook-square"></i>  Facebook Feeds
</div>
<div class="info-space">
	<div class="fb-like-box" data-href="https://www.facebook.com/telfazi" 
	data-width="870" data-height="100%" data-colorscheme="light" data-show-faces="true" data-header="true" data-stream="true" data-show-border="true" style="background:#FFF;"></div>
</div>
<style type="text/css">
.fb-like-box, .fb-like-box span, .fb-like-box.fb_iframe_widget span iframe {
    width: 100% !important;

}
</style>