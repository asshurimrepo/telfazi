<script type="text/javascript">
	var public_url = "{{ $str = str_replace('\\', '/', public_path()); }}";
	var base_url = "{{ url() }}";
	var stream_url = "{{ asset('assets/streamers/') }}";

</script>



          