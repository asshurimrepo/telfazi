@if($feed_total >= $take)
    <div class="row loadbox">
        <div class="col-md-12">
            <div  class="text-center">
                <button id="2" class="btn btn-primary feedmore">Load More</button>
            </div>
        </div>
    </div>
@endif