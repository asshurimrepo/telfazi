@if($type == 'error')
<div class="alert alert-danger" role="alert" id="error-message">
    <b> {{ $message }}</b>
</div>
@endif