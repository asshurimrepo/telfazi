<div class="row">
    <div class="col-md-12">
        <div style="width: 60px;
               position: absolute;
               left: -23px;
               top: 1px;
               ">
            <div class="addthis_sharing_toolbox addthis_default_style">
            </div>
        </div>
    </div>
</div>