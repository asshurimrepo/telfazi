<?php
$banner_size = '300x250';

if(isset($size) && $size)
	$banner_size = $size;


?>
<div>
	<script type="text/javascript"><!--
		e9 = new Object();
		   e9.size = "{{ $banner_size }}";
		//-->
	</script>
	<script type="text/javascript" src="http://tags.expo9.exponential.com/tags/3a6aayercom/ROS/tags.js"></script>
</div>