<div class="row">
	<div class="col-md-12">
	  <div class="text-center upload">
	    No Videos Yet. <a href="{{ URL::to('upload'); }}" class="mybtn btn-channel"> Upload Video </a>
	  </div>
	</div>
</div>