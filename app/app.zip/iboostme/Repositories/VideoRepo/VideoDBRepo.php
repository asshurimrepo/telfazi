<?php
namespace iboostme\Repositories\VideoRepo;


class VideoDBRepo {
    public function __construct(){

    }
} 