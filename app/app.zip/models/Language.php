<?php

class Language extends Eloquent{
	protected $table = 'languages';

}
