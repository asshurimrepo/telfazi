<?php

class VideoThumbnail extends Eloquent {
	protected $table = 'video_thumbnail';
}