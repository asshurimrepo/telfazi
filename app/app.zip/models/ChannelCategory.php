<?php 
class ChannelCategory extends Eloquent{
	protected $table = "channel_categories";
}
