<?php
class StreamerCategory extends Eloquent{
	protected $table = 'streamer_categories';

	
}