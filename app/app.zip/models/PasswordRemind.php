<?php
class PasswordRemind extends Eloquent{
	protected $table = 'password_reminders';
}