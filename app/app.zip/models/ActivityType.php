<?php
class ActivityType extends Eloquent{
	protected $table = 'activity_types';
}