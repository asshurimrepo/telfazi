<?php

class VideoThumbnailSmall extends \Eloquent {
	protected $table = 'video_thumbnail_small';
	protected $fillable = [];
}