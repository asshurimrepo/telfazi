<?php
class AssignedRole extends Eloquent{
	protected $table = 'assigned_roles';
}