<?php

class Setting extends Eloquent {
	protected $table = 'settings';
}