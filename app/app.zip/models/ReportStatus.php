<?php

class ReportStatus extends Eloquent{
	protected $table="report_statuses";
}