<?php

class SettingSeeder extends Seeder{
	
}