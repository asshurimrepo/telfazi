<?php

class VideoSeeder extends Seeder{
	public function run(){
		
	}
}